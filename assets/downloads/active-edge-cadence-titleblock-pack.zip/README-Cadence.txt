Active-Edge Cadence title-block art (2026-08-14 stacked)

PREFERRED (Michael): logo on top, ACTIVE-EDGE / SOLUTIONS / active-esl.com below
  active-edge-solutions-lockup-stacked-transparent-cadence.png

Also: light-text twin, carbon preview, colour/mono BMP, plus legacy horizontal lockups.
