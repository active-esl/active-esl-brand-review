Active-Edge Cadence title-block art

Preferred for light schematic sheets:
  active-edge-solutions-lockup-transparent-cadence.png
  (edge mark + ACTIVE-EDGE SOLUTIONS, transparent background, dark text)

Also included:
  active-edge-solutions-lockup-transparent-cadence-light-text.png  (for dark grounds)
  BMP colour + mono twins in the zip (legacy Cadence BMP import)

Replace the old circuit-head mark with the transparent PNG (or mono BMP) in the title-block logo slot.
If you send the box size in mm or px, we can export an exact-fit file.
