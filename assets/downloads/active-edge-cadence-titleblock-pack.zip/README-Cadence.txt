Active-Edge Cadence title-block art (2026-08-15)

Mark geometry: the white diamond tips now sit inside the arcs -- earlier
art let them poke through the top and bottom of the eye.

PREFERRED (Michael): logo on top, ACTIVE-EDGE / SOLUTIONS / active-esl.com
  White schematic sheet : *-stacked-transparent-cadence-light-bg.png
  Dark sheet or slide   : *-stacked-transparent-cadence.png

Also included: horizontal lockup (same two variants), mark on its own,
carbon preview, and colour/mono BMP for tools that cannot place PNG.
